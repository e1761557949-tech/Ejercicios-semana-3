package tarea.semana.pkg3;

import java.util.*;

public class RegistroProductos {

    public static void main(String[] args) {

        ArrayList<Producto> productos = new ArrayList<>();

        productos.add(new Producto("P01", "Laptop", 800, 3));
        productos.add(new Producto("P02", "Mouse", 25, 10));
        productos.add(new Producto("P03", "Teclado", 40, 4));

        System.out.println("=== Lista de productos ===");

        for (Producto p : productos) {
            System.out.println(p);
        }

        // Buscar producto
        String buscar = "P02";

        for (Producto p : productos) {
            if (p.codigo.equals(buscar)) {
                System.out.println("\nProducto encontrado:");
                System.out.println(p);
            }
        }

        // Ordenar por precio
        productos.sort(Comparator.comparingDouble(a -> a.precio));

        System.out.println("\nProductos ordenados por precio:");

        for (Producto p : productos) {
            System.out.println(p);
        }

        // Stock menor a 5
        System.out.println("\nProductos con stock menor a 5:");

        for (Producto p : productos) {
            if (p.stock < 5) {
                System.out.println(p);
            }
        }
    }
}