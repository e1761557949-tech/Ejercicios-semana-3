package tarea.semana.pkg3;

public class Producto {

    String codigo;
    String nombre;
    double precio;
    int stock;

    public Producto(String codigo, String nombre, double precio, int stock) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Código: " + codigo +
               ", Nombre: " + nombre +
               ", Precio: $" + precio +
               ", Stock: " + stock;
    }
}