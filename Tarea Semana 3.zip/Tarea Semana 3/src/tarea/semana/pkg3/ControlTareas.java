package tarea.semana.pkg3;

import java.util.*;

public class ControlTareas {

    public static void main(String[] args) {

        ArrayList<Tarea> tareas = new ArrayList<>();
        Stack<Tarea> completadas = new Stack<>();

        tareas.add(new Tarea("T01", "Realizar informe", 2));
        tareas.add(new Tarea("T02", "Estudiar Java", 1));
        tareas.add(new Tarea("T03", "Resolver ejercicios", 3));

        // Buscar tarea
        String buscar = "T02";

        for (Tarea t : tareas) {
            if (t.codigo.equals(buscar)) {

                System.out.println("Tarea encontrada:");
                System.out.println(t);

                // Marcar completada
                t.completada = true;

                // Guardar en pila
                completadas.push(t);
            }
        }

        // Ordenar por prioridad
        tareas.sort(Comparator.comparingInt(a -> a.prioridad));

        System.out.println("\nTareas ordenadas:");

        for (Tarea t : tareas) {
            System.out.println(t);
        }

        // Última completada
        System.out.println("\nÚltima tarea completada:");

        System.out.println(completadas.peek());
    }
}