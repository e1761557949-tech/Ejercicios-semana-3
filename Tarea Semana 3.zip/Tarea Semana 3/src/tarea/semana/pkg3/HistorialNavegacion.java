package tarea.semana.pkg3;

import java.util.*;

public class HistorialNavegacion {

    public static void main(String[] args) {

        Stack<String> historial = new Stack<>();

        // Visitar páginas
        historial.push("google.com");
        historial.push("youtube.com");
        historial.push("github.com");

        // Mostrar historial
        System.out.println("=== Historial Actual ===");

        for (String pagina : historial) {
            System.out.println(pagina);
        }

        // Volver a la página anterior
        System.out.println("\nVolviendo a la página anterior...");
        historial.pop();

        // Página actual
        System.out.println("Página actual:");
        System.out.println(historial.peek());

        // Buscar página
        String buscar = "youtube.com";
        boolean encontrado = false;

        for (String pagina : historial) {
            if (pagina.equals(buscar)) {
                encontrado = true;
            }
        }

        if (encontrado) {
            System.out.println("\nLa página fue visitada.");
        } else {
            System.out.println("\nLa página no fue visitada.");
        }

        // Ordenar historial
        ArrayList<String> lista = new ArrayList<>(historial);

        Collections.sort(lista);

        System.out.println("\nHistorial ordenado:");

        for (String pagina : lista) {
            System.out.println(pagina);
        }
    }
}