package tarea.semana.pkg3;

public class Tarea {

    String codigo;
    String descripcion;
    int prioridad;
    boolean completada;

    public Tarea(String codigo, String descripcion, int prioridad) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.prioridad = prioridad;
        this.completada = false;
    }

    @Override
    public String toString() {
        return "Código: " + codigo +
               ", Descripción: " + descripcion +
               ", Prioridad: " + prioridad +
               ", Estado: " + (completada ? "Completada" : "Pendiente");
    }
}