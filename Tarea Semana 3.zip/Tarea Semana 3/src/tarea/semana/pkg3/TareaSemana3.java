
package tarea.semana.pkg3;

import java.util.*;

public class TareaSemana3 {

    public static void main(String[] args) {

        Queue<Paciente> cola = new LinkedList<>();

        cola.offer(new Paciente("Ana", "0101", "Medicina General"));
        cola.offer(new Paciente("Luis", "0202", "Pediatría"));
        cola.offer(new Paciente("Carlos", "0303", "Odontología"));

        System.out.println("=== Pacientes en espera ===");

        for (Paciente p : cola) {
            System.out.println(p);
        }

        System.out.println("\nAtendiendo paciente...");
        Paciente atendido = cola.poll();
        System.out.println(atendido);

        System.out.println("\nBuscar paciente por cédula:");

        String buscar = "0202";

        for (Paciente p : cola) {
            if (p.cedula.equals(buscar)) {
                System.out.println("Paciente encontrado: " + p);
            }
        }

        ArrayList<Paciente> lista = new ArrayList<>(cola);

        Collections.sort(lista, (a, b) -> a.nombre.compareTo(b.nombre));

        System.out.println("\nPacientes ordenados:");

        for (Paciente p : lista) {
            System.out.println(p);
        }
    }
}