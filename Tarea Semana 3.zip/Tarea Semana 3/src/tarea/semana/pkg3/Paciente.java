package tarea.semana.pkg3;

public class Paciente {

    String nombre;
    String cedula;
    String consulta;

    public Paciente(String nombre, String cedula, String consulta) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.consulta = consulta;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre +
               ", Cédula: " + cedula +
               ", Consulta: " + consulta;
    }
}